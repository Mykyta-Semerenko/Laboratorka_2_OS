# Частина 4. Відповіді

## Виміри

| Сторінок | mmap          | read | first write | second write | after MADV_DONTNEED |
| -------- | ------------- | ---- | ----------- | ------------ | ------------------- |
| 256      | faults / ΔRSS |      |             |              |                     |
| 1024     |               |      |             |              |                     |
| 4096     |               |      |             |              |                     |
| 16384    |               |      |             |              |                     |

## Пояснення кожного кроку

- mmap:
- read every page:
- first write:
- second write:
- write after MADV_DONTNEED:

## Перевірка зовнішніми інструментами

`/usr/bin/time -v` (Maximum resident):

`strace -e trace=mmap,munmap,madvise ./pagefaults 16`, ваш рядок mmap:

## Варіація

Яку обрали, що змінилося і чому:
